﻿
namespace DataAccessLayer;

public interface IConfigDatabase {
    string ConnectionStringDb { get; }
}
﻿namespace BusinessLayer;

public interface IConfigOpenWeatherService {
    string WeatherApiKey { get; }
}
﻿namespace BusinessLayer;

public interface IConfigOpenRouteService {
    string ApiKey { get; }
}
﻿using System.Windows.Controls;

namespace Tour_Planner.Views;

public partial class MenuView : UserControl {
    public MenuView() {
        InitializeComponent();
    }
}
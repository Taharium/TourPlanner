﻿using System.Windows.Controls;

namespace Tour_Planner.Views {
    /// <summary>
    /// Interaction logic for TourLogView.xaml
    /// </summary>
    public partial class TourLogsView : UserControl {
        public TourLogsView() {
            InitializeComponent();
        }
    }
}

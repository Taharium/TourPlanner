﻿using System.Windows.Controls;

namespace Tour_Planner.Views;

public partial class TourListView : UserControl {
    public TourListView() {
        InitializeComponent();
    }
}
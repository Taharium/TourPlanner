﻿using System.Windows;

namespace Tour_Planner.WindowsWPF {
    /// <summary>
    /// Interaction logic for AddTourLogWindow.xaml
    /// </summary>
    public partial class AddTourLogWindow : Window {
        public AddTourLogWindow() {
            InitializeComponent();
        }
    }
}

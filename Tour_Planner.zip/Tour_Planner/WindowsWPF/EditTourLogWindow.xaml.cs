﻿using System.Windows;

namespace Tour_Planner.WindowsWPF
{
    /// <summary>
    /// Interaction logic for EditTourLogWindow.xaml
    /// </summary>
    public partial class EditTourLogWindow : Window
    {
        public EditTourLogWindow()
        {
            InitializeComponent();
        }
    }
}

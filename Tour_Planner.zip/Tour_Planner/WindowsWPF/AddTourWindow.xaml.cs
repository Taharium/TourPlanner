﻿using System.Windows;

namespace Tour_Planner.WindowsWPF {
    /// <summary>
    /// Interaction logic for AddTourWindow.xaml
    /// </summary>
    public partial class AddTourWindow : Window {
        public AddTourWindow() {
            InitializeComponent();
        }
    }
}

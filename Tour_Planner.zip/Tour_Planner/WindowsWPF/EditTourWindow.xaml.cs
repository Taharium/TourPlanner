﻿using System.Windows;

namespace Tour_Planner.WindowsWPF {
    /// <summary>
    /// Interaction logic for EditTourWindow.xaml
    /// </summary>
    public partial class EditTourWindow : Window {
        public EditTourWindow() {
            InitializeComponent();
        }
    }
}

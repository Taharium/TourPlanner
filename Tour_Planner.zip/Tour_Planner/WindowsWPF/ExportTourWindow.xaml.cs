﻿using System.Windows;

namespace Tour_Planner.WindowsWPF;

public partial class ExportTourWindow : Window {
    public ExportTourWindow() {
        InitializeComponent();
    }
}
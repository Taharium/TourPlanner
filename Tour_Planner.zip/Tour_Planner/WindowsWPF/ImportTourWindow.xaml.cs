﻿using System.Windows;

namespace Tour_Planner.WindowsWPF;

public partial class ImportTourWindow : Window {
    public ImportTourWindow() {
        InitializeComponent();
    }
}
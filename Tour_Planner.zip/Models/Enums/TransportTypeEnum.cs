﻿namespace Models.Enums {
    public enum TransportType {
        Car,
        Cycling,
        Foot,
        Wheelchair
    }
}

﻿namespace Models.Enums;

public enum Child_Friendliness
{
    HighlyChildFriendly,
    ChildFriendly,
    CautionAdvised,
    NotSuitable
}
﻿namespace Models.Enums {

    public enum Difficulty {
        Easy = 1,
        Medium = 2,
        Hard = 3
    }
}

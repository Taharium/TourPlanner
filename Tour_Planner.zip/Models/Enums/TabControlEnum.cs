﻿namespace Models.Enums {
    public enum TabControlEnum {
        General,
        Route,
        DestinationWeather,
        Joke
    }
}

﻿namespace Models.Enums;

public enum Popularity
{
    Unpopular,
    Known,
    Popoular,
    VeryPopular
}